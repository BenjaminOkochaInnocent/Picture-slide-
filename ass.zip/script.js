document.addEventListener('DOMContentLoaded', function () {
    var a = document.getElementById('featured-image').querySelector('img');
    var y = document.getElementById('thumbnails');
    var t = thumbnails.getElementsByTagName('img');

    for (let i = 0; i < t.length; i++) {
        t[i].addEventListener('click', function () {
            a.src = this.src;
        });
    }
});
